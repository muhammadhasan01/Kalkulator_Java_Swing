package kalkulator;

/**
 *
 * @author Muhammad Hasan - 13518012
 */
public interface duaEkspresi {
    public double getHasil();
}
