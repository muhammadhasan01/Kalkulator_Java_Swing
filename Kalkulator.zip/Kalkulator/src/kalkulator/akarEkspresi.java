package kalkulator;

/**
 *
 * @author USER
 */
public class akarEkspresi extends ekspresi {
    // menghasilkan nilai pengakaran ekspresi
    public double getHasil() {
        double num = 0.0; // isi nilai num dengan this.getNilai()
        if (num < 0) {
            // lakukan throw
        }
        // kembalikan nilai pengakaran ekspresi
        return 0;
    }
}
